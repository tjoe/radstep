<?php

/**
 * Configuration file for: Database Connection 
 * This is the place where your database constants are saved
 */

define("DB_HOST", "127.0.0.1");
define("DB_NAME", "login");
define("DB_USER", "root");
define("DB_PASS", "");